/**
 * Names: Omar Masri and Brandon Weinstein
 * X.500s: weins127 masri013
 */

public class RunnyQueue<T>{
    private int count;
    private RunnyQueueNode<T> tail;
    private RunnyQueueNode<T> head;
    
    public RunnyQueue() {
        //set head to null and count to zero
        head = null;
        count = 0;
    }

    public void enqueue(T data) {
        if (isEmpty()) {
            //if empty, create new head and set next -> tail, and tail -> head
            head = new RunnyQueueNode<>(data, tail);
            tail = head;
        } else {
            if (tail.getData() == data) {
                //if last element data's are equal, increase count, dont add element(Runny)
                tail.setCount(tail.getCount() + 1);
            } else {
                //if new data, add new node
                RunnyQueueNode<T> next = new RunnyQueueNode<>(data, tail);
                // set old tail to point to new tail (next)
                tail.setNext(next);
                // set next as new tail
                tail = next;
                // point new tail to head
                tail.setNext(head);
            }   
        }
        //increment count
        count++;
    }

    public T dequeue() {
        // return null if empty
        if (isEmpty()) {
            return null;
        } else {
            //check if count of item will still be greater than zero when removing
            if (head.getCount() - 1 > 0) {
                head.setCount(head.getCount() - 1);
                count--;
                return head.getData();
            //otherwise reassign next head (getting rid of item in queue)
            } else {
                    T old = head.getData();
                    head = head.getNext();
                    count--;
                    return old;
            }
        }
    }
    
    public T front() {
        if (isEmpty()) {
            return null;
        }
        return head.getData();
    }

    public int frontRunLength() {
        if (isEmpty()) {
            return 0;
        } else {
            return head.getCount();
        }  
    }

    public int getSize(){
        return count;
    }

    public boolean isEmpty(){
        if(count == 0){
            return true;
        } else {
            return false;
        }
    }

    public String toString() {
        String output = "";
        //start with head of queue
        RunnyQueueNode<T> currNode = head;
        if (!isEmpty()) {
            while (currNode != tail) {
                output += currNode.toString() + ", ";
                currNode = currNode.getNext();
            }
            //don't add comma for tail
            output += tail.toString();
        }
        return output;
    }
}